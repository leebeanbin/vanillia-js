const tomatos = document.querySelector("#tomatos");

const BASE_COLOR = "rgb(0, 0, 0)";
const mouseOnColor = "#009966";
const mouseOutColor = "#FF6633";
const resizeColor = "#FF3399";
const rightClickColor = "#666666";

function mouseOn() {
    const currentColor = tomatos.style.color;
    if (currentColor != mouseOnColor){
        tomatos.style.color = mouseOnColor;
        tomatos.innerHTML = "Mouse is here!"
    

    }
}

tomatos.addEventListener("mouseup",mouseOn);