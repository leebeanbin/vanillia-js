const select = document.querySelector('select')

select.addEventListener('change', (e)=>{
  const selected = e.target.value
  localStorage.setItem('COUNTRY', selected)
})