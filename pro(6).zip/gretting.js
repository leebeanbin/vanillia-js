const form = document.querySelector(".js-form"),
    input = document.querySelector("input");


const USER_LS = "currentUser"
function loadName(){
    const currentUser = localStorage.getItem(USER_LS)
    if(currenUser === null){

    }else {
        
    }
}

function init(){

}
init();

/* localStorage.setItem("bean",true); 하고 실행하면 localStorage에
key:bean value:true가 저장되고 getItem("bean")을 하면 true가 나온다.
그리고 시시각각 value를 바꿀 수도 있음*/