const apple = document.querySelector("body");
const pear = ["rgb(52, 152, 219)", "rgb(245, 176, 65)", "rgb(155, 89, 182)"];


const superMagic = {
  Bla: function() {
    const grape = window.innerWidth;
    if(grape < 800 && grape >350 ){
      apple.style.backgroundColor = pear[2];
    }
    if (grape >= 800) {
      apple.style.backgroundColor = pear[0];
      
    } else if (grape <= 350) {
      apple.style.backgroundColor = pear[1];
    }
  }
};

function init(){
  window.addEventListener("resize", superMagic.Bla);
}

init();
